import time

i=12

while i>0:

  localtime = time.asctime(time.localtime(time.time()))

  print "Local current time :", localtime

  time.sleep(5)

  i=i-1

start = time.time()

list1 = ['a','b','c','d','e']

list2 = [1,2,3,4,5,6,7]

list3 = ['e','d','c','b','a']

print list1

print list2

print list3

print "Length of list1=",len(list1)

print "Length of list2=",len(list2)

print "Length of list3=",len(list3)

print "Time Taken=", time.time()-start