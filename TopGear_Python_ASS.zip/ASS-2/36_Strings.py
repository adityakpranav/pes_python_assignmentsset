tup1=('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')


tup2=('Sunday','Monday','Wednesday','Thursday','Friday','Saturday')


print "tup1 is",tup1

print "tup2 is",tup2

print "cmp(tup1,tup2)=",cmp(tup1,tup2)

print "cmp(tup2,tup1)=",cmp(tup2,tup1)

print "Length of tup1 is",len(tup1)

print "Length of tup2 is",len(tup2)

print "Max of tup1 is",max(tup1)

print "Max of tup2 is",max(tup2)

print "Min of tup1 is",min(tup1)

print "Min of tup2 is",min(tup2)

aList = (123, 'xyz', 'zara', 'abc')

aTuple = tuple(aList)

print "Tuple elements are",aTuple