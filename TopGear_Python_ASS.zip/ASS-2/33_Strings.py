List=[10,20,30,40,50,60,70]

print List

List.append(80)

print "The Appended list is",List

List.insert(3,100)

print "The list after inserting 100 at 4th position is",List

List.sort()

print "List after sorting is",List

List.reverse()

print "The list in descending order",List

List.pop()

List.pop()

List.pop()

print "List after removing last 3 elements",List

