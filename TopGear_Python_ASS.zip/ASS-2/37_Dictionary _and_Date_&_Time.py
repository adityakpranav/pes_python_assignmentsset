dict1={'Rollno':1,'Name':'Name1','Class':1}

dict2={'Rollno':2,'Name':'Name2','Class':2}

dict3={'Rollno':3,'Name':'Name3','Class':3}


if dict1>dict2 and dict1>dict3:

  print "dict1 is th biggest",dict1

elif dict2>dict1 and dict2>dict3:

  print "dict2 is the biggest",dict2

else:

  print "dict3 is the biggest",dict3

dict1['Class']=2

dict2['School']='St. Pauls'

print "\ndict1 after adding new elements is",dict1

print "\ndict2 after adding new elements is",dict2

print "Length of dict1 is",len(dict1)

print "Length of dict2 is",len(dict2)

print "Length of dict3 is",len(dict3)

dict1Str=str(dict1)

dict2Str=str(dict2)

dict3Str=str(dict3)

dictStr=dict1Str+dict2Str+dict3Str

print "the concatenated dicts as strings all together is",dictStr