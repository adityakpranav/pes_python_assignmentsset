myStr=input("Enter the string")

#myStr="Hello buddy"

myStr1=myStr[::-1]

if myStr==myStr1:

  print "The given string",myStr,"is palindrome"

else:

  print "The given string",myStr,"is not palindrome"