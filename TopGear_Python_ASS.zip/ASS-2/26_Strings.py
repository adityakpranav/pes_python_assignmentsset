
encStr = "3faa77d911c5ffb5b104cbf1a3676382="

decStr = encStr.decode('base64','strict')

print "Encoded String: " + encStr

print "Decoded String: " + decStr