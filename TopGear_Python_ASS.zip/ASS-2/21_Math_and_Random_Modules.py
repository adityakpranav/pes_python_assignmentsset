import math

import random

num1=0.543

print "The round off to next decimal for",num1,"is",round(num1,0)

num2=990

print "The sqrt of number",num2,"is",math.sqrt(num2)

print "A random number between 0 and 1 using random function is",random.random()

print "A random number between 10 and 500 using uniform function is",random.uniform(10,500)



print "BELOW STARTS FOR MATH FUNCTIONS LIST"

print "abs(-1.8)=",abs(-1.8)

print"\nceil(1.3)=",math.ceil(1.3)

print"ceil(-1.3)=",math.ceil(-1.3)

print "ceil(1.6)=",math.ceil(1.6)

print "ceil(-1.6)=",math.ceil(-1.6)

print "\ncmp(3,4)=",cmp(3,4)

print "cmp(10,4)=",cmp(10,4)

print "cmp(4,4)=",cmp(4,4)

print "\nexp(2)=",math.exp(2)

print "\nfabs(-1.4)=",math.fabs(-1.4)

print "\nfloor(1.6)=",math.floor(1.6)

print "floor(-1.6)=",math.floor(-1.6)

print "floor(1.2)=",math.floor(1.2)

print "floor(-1.2)=",math.floor(-1.2)

print "\nlog(2)=",math.log(2)

print "\nlog10(2)=",math.log10(2)

print "\nmax(2,34,55,56)=",max(2,34,55,56)

print "\nmin(2,34,55,56)=",min(2,34,55,56)

print "\nmodf(100.233444)=",math.modf(100.233444)

print "math.modf(math.pi)=",math.modf(math.pi)

print "\npow(2,3) i.e 2**3=",pow(2,3)

print "\nround(80.23456, 2)=",round(80.23456, 2)

print "round(100.000056, 3)=",round(100.000056, 3)

print "round(-100.000056, 3)=",round(-100.000056, 3)

print "\nSqrt(3)=",math.sqrt(3)

print "\nBELOW STARTS FOR RANDOM FUNCTIONS LIST"

print "choice([1, 2, 3, 5, 9])=",random.choice([1, 2, 3, 5, 9])

print "choice('A String')=",random.choice('A String')

print "\nPrinting a number where start=100,end=1000,step=2"

print "randrange(100, 1000, 2) =",random.randrange(100, 1000, 2)

print "\nPrinting a number where start=100,end=1000,step=3"

print "randrange(100, 1000, 3)=",random.randrange(100, 1000, 3)

print "\nFirst random number=",random.random()

print "Second random number=",random.random()

random.seed( 10 )

print "Random number with seed 10=",random.random()

# It will generate same random number

random.seed( 10 )

print "Random number with seed 10=",random.random()

print "Random number",random.random()

print "Random number",random.random()

print "Random number",random.random()

list = [2, 13, 133, 51,'A'];

random.shuffle(list)

print "\nReshuffled list=",list

random.shuffle(list)

print "Reshuffled list=",list

print "\nRandom Float uniform(2,14)=",random.uniform(2,14)

print "Random Float uniform(4,11)=",random.uniform(4,11)