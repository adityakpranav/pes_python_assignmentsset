print "My name is %s and weight is %d kg!" % ('Zara', 21)

print "my name is %c (example for for character)"%('A')

print "My name is %s (example for string conversion)"%('Rahul')

print "the no is %i (signed decimal integer)"%(-2)

print "the no is %d (signed decimal integer)"%(2)

print "the no is %u (unsigned decimal integer)"%(-2)

print "octal integer for 21 is %o"%(21)

print "hexadecimal integer (lowercase letters) of 21 is %x"%(21)

print "hexadecimal integer (uppercase letters) of 21 is %X"%(21)

print "exponential notation (with lowercase 'e') of 21 is %e"%(21)

print "exponential notation (with UPPERcase 'E') of 21 is %E"%(21)

print "floating point real number is %f"%23

print "%g"%21

print "%G"%21