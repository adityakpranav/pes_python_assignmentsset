

file = open("file.txt", "r+")

print "Name of the file: ", file.name

# Close file
file.close()

file = open("file.txt", "r")

print "Name of the file: ", file.name

file.flush()

file.close()



file = open("file.txt", "r+")

print "Name of the file: ", file.name

fid = file.fileno()

print "File Descriptor: ", fid

file.close()



file = open("file.txt", "r+")

print "Name of the file:", file.name

ret = file.isatty()

print "Return value : ", ret

file.close()



file = open("file.txt", "r+")

print "Name of the file: ", file.name

for index in range(1):

   line = file.next()

   print "Line No %d - %s" % (index, line)

file.close()



file = open("file.txt", "r+")

print "Name of the file: ", file.name

line = file.read(100)

print "Read Line: %s" % (line)

file.close()



file = open("file.txt", "r+")

print "Name of the file: ", file.name

line = file.readline()

print "Read Line: %s" % (line)

line = file.readline(5)

print "Read Line: %s" % (line)

file.close()



file = open("file.txt", "r+")

print "Name of the file: ", file.name

line = file.readlines()

print "Read Line: %s" % (line)

line = file.readlines(2)

print "Read Line: %s" % (line)

file.close()



file = open("file.txt", "rw+")

print "Name of the file: ", file.name

line = file.readline()

print "Read Line: %s" % (line)

# Again set the pointer to the beginning

file.seek(0, 0)

line = file.readline()

print "Read Line: %s" % (line)

file.close()



file = open("file.txt", "rw+")

print "Name of the file: ", file.name

line = file.readline()

print "Read Line: %s" % (line)

# Get the current position of the file.

pos = file.tell()

print "Current Position: %d" % (pos)

# Close opend file

file.close()





file = open("file.txt", "rw+")

print "Name of the file: ", file.name

line = file.readline()

print "Read Line: %s" % (line)

# Now truncate remaining file.

file.truncate()

# Try to read file now

line = file.readline()

print "Read Line: %s" % (line)

file.close()



file = open("file.txt", "rw+")

print "Name of the file: ", file.name

str = "This is 6th line"

# Write a line at the end of the file.

#file.seek(0, 1)

line = file.write( str )

# Now read complete file from beginning.

file.seek(0,0)

lines=file.read()

print lines

file.close()



file = open("file.txt", "rw+")

print "Name of the file: ", file.name

str = "This is 6th line"

# Write a line at the end of the file.

#file.seek(0, 1)

line = file.writelines( str )

# Now read complete file from beginning.

file.seek(0,0)

lines=file.read()

print lines

file.close()