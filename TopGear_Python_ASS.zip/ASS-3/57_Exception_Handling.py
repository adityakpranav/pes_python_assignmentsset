
#1
i=1

try:

    while(i<500):

        print i
        i+=1

except KeyboardInterrupt:
    print "KeyboardInterrupt"
    
#2
try:

    name = input("Enter name:")

    print name

except NameError:#Enter your name in Quotes else NameError msg will appear

    print "NameError"


#3
try:

    num= 0/0

except ArithmeticError:

    print "ArithmeticError"
#4
try:

    file =open("file.txt","r")

    print file.read()

    file.write("Hello")

except IOError:

    print "IOError for Writing"

#5

try:

    import aditya

except ImportError:

    print "Importing error"


    