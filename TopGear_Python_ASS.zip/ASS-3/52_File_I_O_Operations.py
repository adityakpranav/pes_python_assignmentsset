
strlist=list()
for lines in reversed(open("file.txt").readlines()):

    print lines.rstrip()

    strlist.append(lines.rstrip())

    
# b reversing each word
for string in strlist:

    print string[::-1]
