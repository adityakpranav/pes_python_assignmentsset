try:

    file =open("file.txt","r")

    print file.read()

    file.write("Hello")

except IOError:

    print "IOError for Writing"



try:

    num = int(input("Enter value:"))

except ValueError:

    print "ValueError"

