file=open("file1.txt","r")

pos=0

while(True):

    a=file.read(10)

    if not a:

        break

    else:

        print a

        pos+=10

        print pos


#b
file=open("file1.txt","r")

pos=0

while(pos<100):

    a=file.read(10)

    if not a:

        break

    else:

        print a

        pos+=10

        print "pos=",pos        

file.seek(0,0)

print file.read(10)



file=open("file1.txt","r")

for i in range(5):

    file.readline()

for line in file:	

	print "line=",line

file.close()