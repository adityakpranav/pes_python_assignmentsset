
def add(a,b):
  print "Sum of a and b =",a+b

def diff(a,b):
  print "Difference of a and b =",a-b
    

def multiply(a,b):
  print "Multiplication of a and b =",a*b




def div(a,b):
  print "Division of a and  b =",a/b

    

def sqroot(a):
    print "Square root of the number",a,"=", a**.5

    

def floor_div(a,b):

    print "Floor division of a and b =", a//b

    

def fib(nterms):
  a=0
  b=1
  if nterms<=0:



    print("please enter positive number")

  elif nterms==1:

    print("Fibonacci series:",a)

  elif nterms==2:

    print a

    print b

  else:

    print a

    print b

    while(nterms>2):

      numnext=a+b

      print numnext

      a=b

      b=numnext

      nterms=nterms-1





def isprime(num):

    for i in range(2,num//2):
        if num%i==0:
            print num,"not prime"
            break
	else:
		print num,"is prime"


#number=int(raw_input())        

#isprime(number)        

