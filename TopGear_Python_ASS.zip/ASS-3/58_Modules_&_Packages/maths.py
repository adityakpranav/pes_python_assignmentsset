from calc import add
from calc import diff
from calc import multiply
from calc import div
from calc import sqroot
from calc import floor_div
from calc import fib
from calc import isprime

add(1,2)

diff(4,2)

multiply(50,17)

div(66,20)

sqroot(16)

floor_div(50,6)

fib(5)

isprime(591)