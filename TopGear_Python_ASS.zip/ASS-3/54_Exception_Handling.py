
#a
i=1

try:

    while(i<500):

        print i
        i+=1

except KeyboardInterrupt:
    print "KeyboardInterrupt"
    
#b
try:

    name = input("Enter name:")

    print name

except NameError:#Enter your name in Quotes else NameError msg will appear

    print "NameError"


#c
try:

    num= 0/0

except ArithmeticError:

    print "ArithmeticError"

    