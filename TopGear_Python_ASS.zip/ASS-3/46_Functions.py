def maxReq(a,b,c,d):
	return(max(a,b,c,d))
def maxDefault(a=1,b=4,c=5,d=0):
	return(max(a,b,c,d))
print(maxReq(2,3,4,5))
print(maxDefault())
