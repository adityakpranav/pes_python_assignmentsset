nums = list(range(20))
def search(*args):
    print(args)
    for arg in args:
        if arg in nums:
            print('Found =',arg)


search(2,3)
search(4,5)