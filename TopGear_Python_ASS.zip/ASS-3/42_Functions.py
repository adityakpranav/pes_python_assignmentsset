from __future__ import print_function
def fib(n): 
    a = 0
    b = 1
    if n < 0: 
        print("Incorrect input") 
    elif n == 0: 
        print(a) 
    else:
        print(a,end = ', ')
        print(b,end=', ')
        for i in range(2,n): 
            c = a + b 
            a = b 
            b = c
            print(b,end=',')
        print('\b\b')
        
num = input('Enter number:')
fib(num)