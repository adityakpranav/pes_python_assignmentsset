def poundToKgNegative(pound):

  try:

    assert (pound>=0),"Entered Negative weight"

    return pound*0.453592

  except AssertionError, exp:

    return exp

print poundToKg(-50)





#b
def poundToKgWeight(pound):

  try:

    assert (pound>100), "Weight should be more than 100 Kg"

    return pound*0.453592

  except AssertionError, exp:

    return exp


print poundToKgWeight(101)

