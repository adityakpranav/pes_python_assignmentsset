import math

def Addition(a,b):


  sum=a+b

  print "sum is",sum

def Subtraction(a,b):


  sub=a-b

  print "Subtraction is",sub

def Multiply(a,b):

  mul=a*b

  print "multiplication is",mul

def Division(a,b):


  div=a/b

  print "Division is",div

def Sqrt(num):


  print "SQrt is ",math.sqrt(num)

Addition(3,5)

Subtraction(9,3)

Multiply(3,5)

Division(4,2)

Sqrt(9)

Sqrt(num=81)

# b
def StrSplit(str,Del):
	return(str.split(Del))
Str = "Pack: My: Box: With: Good: Food"
Del = ':'
print StrSplit(Str,Del)