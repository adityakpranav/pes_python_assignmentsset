
def concatTuple(tup1,list1):
  list1_tup2=tuple(list1)

  result=tup1+list1_tup2

  print (result)

tup1=(1,2,3,4)

list1=[11,22,33,44]

concatTuple(tup1,list1)