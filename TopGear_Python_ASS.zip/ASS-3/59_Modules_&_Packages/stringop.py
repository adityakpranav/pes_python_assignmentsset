def sortNumbers(num):

  for i in range(len(num)-1):

    for j in range(len(num)-1):

      if num[j] > num[j+1]:

        temp = num[j]

        num[j] = num[j+1]

        num[j+1] = temp

  print "Sorted list= ", num

    

def binarySearch(list1, item):

    list1.sort()

    first = 0

    last = len(list1)-1

    found = False
    while first<=last and not found:

        mid = (first+last)/2

        if list1[mid] == item:

            found = True

            print 'found'

        else:

            if item < list1[mid]:

                last = mid-1

            else:

                first = mid+1

    return 'Not found'

def reverselist(list2):
    print "reversed list :", list2.reverse()



