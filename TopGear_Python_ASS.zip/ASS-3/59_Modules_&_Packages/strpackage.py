from stringop import sortNumbers
from stringop import binarySearch
from stringop import reverselist

list = [10,25,30,58,65,98,4,1,857]

print 'Sort List:',list
sortNumbers(list)

print 'binarySearch in :',list
binarySearch(list,1)

print 'Reverse list:',list
reverselist(list)