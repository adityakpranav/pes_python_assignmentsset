file = open("File1.txt","r")

print "File Content : ",file.read()

file.close()

file=open("File2.txt","w")

file.writelines("Line1 \n Line2 \n Line3 \n Line4 \n Line5")

file.close()

file=open("File2.txt","a")

file.writelines("AgainLine1 \n AgainLine2 \n AgainLine3 \n AgainLine4 \n AgainLine5")

file.close()