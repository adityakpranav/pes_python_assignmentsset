def isPallRequired(str):
    if str == str[::-1]:
        print('Pallindrome')
    else:
        print('Not Pallindrome')
def isPallDefault(str='malayalam'):
    print(str)
    if str == str[::-1]:
        print('Pallindrome')
    else:
        print('Not Pallindrome')

isPallRequired('abac')
isPallDefault()