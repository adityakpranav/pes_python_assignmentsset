lst_10 = tuple(range(10))
#a
for item in lst_10:
    print(item)
#b
print(lst_10[-1:0:-1])

#c
print(lst_10*2)

#d
print(lst_10+(10,11,12))