num1 = int(input("Enter Number: "))
num2 = int(input("Enter Number: "))
temp = [num1 for _ in range(7)]
temp[0]+=num2

temp[1]-=num2

temp[2]*=num2

temp[3]/=num2

temp[4]%=num2

temp[5]**=num2

temp[6]//=num2



print("Addition :{}, Substation :{}, Multiplication :{}, Division :{}, Modulus :{}, Exponent :{} and Floor division :{} operations".format(*temp)