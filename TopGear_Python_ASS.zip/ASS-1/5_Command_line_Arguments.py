import argparse
parser = argparse.ArgumentParser()
parser.add_argument('integers', metavar='N', type=int, nargs='+')
args = parser.parse_args()
num = args.integers
# a
if(num[0] == 5and len(num)==6):
	for nu in num[1:]:
		print(nu)
# b
elif(num[0] == 3 and len(num)==4):
	print("Max of num1: {0}\n num2: {1} \n num3: {2}\n max: {3}".format(num[1],num[2],num[3],num[1] if(num[1]>num[2] and num[1]>num[2]) else (num[2] if(num[2]>num[3]) else num[3])))
else:
	print("Bad Argument")

	