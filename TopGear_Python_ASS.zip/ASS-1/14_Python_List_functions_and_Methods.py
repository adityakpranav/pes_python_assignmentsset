A = list(range(1,11))
B = ['Employee'+str(i) for i in A]

#a
for name in B:
	print(name)
	
#b
index = int(input("Enter index:"))
print('id : %d\nEmployee Name: %s'%(A[index],B[index]))

#c
print(B[4:10])

#d
print(B[3:])

#e
num  = int(input("Enter number:"))
A_e = A+A*num
B_e = B+B*num

#f
print("New A list:{}".format(A_e))
print("New B list:{}".format(B_e))

#g
print('id\tEmployee Name')
for i in range(len(A_e)):
    print(" {}\t{}".format(A_e[i],B_e[i]))