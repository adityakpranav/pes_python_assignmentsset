# a
for i in range(1,101):
	print(i)

for i in range(100,0,-1):
	print(i)
# b
i = 1
while i<=100:
	print(i)
	i+=1

i = 100
while i>0:
	print(i)
	i-=1
# c

mystring ="Hello world"
for ch in mystring:
	print(ch)