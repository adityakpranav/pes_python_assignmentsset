#str = input()
str = 'abcde'
for ch in str:
    print(ch)
#a
print(str[-1::-1])

#b
str_b = str*100
print(str_b)

#c
str_c = input()
print(str+str_c)