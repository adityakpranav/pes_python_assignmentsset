num=1
count=0
N=3
def prime(n):
      j=2
      while j<=n//2:
            if n%j==0:
                  return False
            j=j+1
      return True
 
# N=int(input('Number : '))
N = 4
while count<=N:
      num=num+1
      if prime(num):
            count+=1
            print(count,'th prime is ',num)
 