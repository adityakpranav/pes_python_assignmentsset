nums = []
for i in range(10):
    nums.append(int(input("Enter {}th number: ".format(i))))
avg = sum(nums)/10

print(list(filter(lambda i: i<avg,nums)))
print(list(filter(lambda i: i>avg,nums)))
print(list(filter(lambda i: i==avg,nums)))



    