nums = []

#count = int(input("Enter number of elements: "))
count = 4
max = None
for _ in range(count):
	nums.append(int(input("Enter number: ")))


if nums[0]>nums[1] and nums[0]>nums[2] and nums[0]>nums[3]:
	max = nums[0]
elif nums[1] >nums[2] and nums[1] > nums[3]:
	max = nums[1]
elif nums[2]>nums[3]:
	max = nums[2]
else:
	max = nums[3]
print("Max till 4 is %d"%max)
#b largest among 5
nums.append(int(input("Enter number 5th number: ")))
	
if max < nums[4]:
	max = nums[4]

print("Max after 5th is %d"%max)