a = int(input("Enter Number: "))
b = int(input("Enter Number: "))
    
# Print bitwise AND operation    
print("a & b =", a & b)  
    
# Print bitwise OR operation  
print("a | b =", a | b)  
    
# Print bitwise NOT operation   
print("~a =", ~a)  
    
# print bitwise XOR operation   
print("a ^ b =", a ^ b)  

# print bitwise right shift 
print("a>>b =", a>>b)  

# print bitwise left shift 
print("a<<b =", a<<b)  
