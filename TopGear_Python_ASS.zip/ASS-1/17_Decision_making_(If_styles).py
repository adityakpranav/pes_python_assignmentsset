lst = list(range(10))
print('biggest: ',max(lst), ' smallest: ',min(lst))