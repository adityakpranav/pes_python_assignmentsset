
for i in range(1,101):
	print(i)
# a
for i in range(1,101):
	if i == 50:
		break
	elif i in range(10,60,10):
	elif i%2==0:
		print(i)
		continue
	else:
		pass

# b
i = 0
while i<=100:
	i+=1
	if i==90:
		break
	elif i in [60,70,80,90]:
		continue
	else:
		pass

