num1 = int(input("Enter First Number: "))
num2 = int(input("Enter Second Number: "))
num3 = int(input("Enter Third Number: "))

print("Max of num1: {0}\n num2: {1} \n num3: {2}\n max: {3}".format(num1,num2,num3,num1 if(num1>num2 and num1>num2) else (num2 if(num2>num3) else num3)))

