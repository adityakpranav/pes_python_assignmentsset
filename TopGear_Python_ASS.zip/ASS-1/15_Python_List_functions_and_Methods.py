Names = ['Name'+str(i) for i in range(1,6)]
# a 
name = input("Enter Name: ")
print("Entered name is %s"%('Present' if name in Names else 'not present'))

# b
name = input("Enter Name: ")

index = 0
op = 'Not Found'
while index<len(Names):
    if Names[index] == name:
        op = 'Found'
        break
    index+=1
print("Entered name is %s"%op)

# c
index = len(Names)-1
while index>-1:
    print('Name : %s'%Names[index])
    index-=1
