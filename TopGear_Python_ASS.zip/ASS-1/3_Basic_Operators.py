
num1 = int(input("Enter Number: "))
print('Even' if (num1%2==0) else 'Odd')